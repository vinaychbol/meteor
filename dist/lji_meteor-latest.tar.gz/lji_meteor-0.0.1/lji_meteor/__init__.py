"""
LJI Meteor CLI tool for managing AWS resources
"""
from .main import app

__version__ = "0.0.1"
__all__ = ['app']
